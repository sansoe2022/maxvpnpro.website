package tarnage.vpsvpn.net.api;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.downloader.Error;
import com.downloader.OnDownloadListener;
import com.downloader.PRDownloader;
import java.io.File;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import tarnage.vpsvpn.net.OpenVPNClient;
import tarnage.vpsvpn.net.R;
import android.widget.Toast;

public class UpdateFilesApi {
    private static final String api = "https://raw.githubusercontent.com/Tarnagetk/-/main/%E1%80%96%E1%80%AD%E1%80%AF%E1%80%84%E1%80%BA%E1%80%9C%E1%80%84%E1%80%BA%E1%80%B7json";
    private static Activity activity;
    private static File downloadFolder;
    private static boolean silentCheck;
    private static int updatePosition = 0;
    public static String DOWNLOAD_FOLDER = "DownloadedFiles";

    private static class OvpnUpdateModel {
        public final String name, url;
        public OvpnUpdateModel(String name, String url) {
            this.name = name;
            this.url = url;
        }
    }

    public static void triggerRebirth(Context context) {
        Intent intent = new Intent(context, OpenVPNClient.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
        Runtime.getRuntime().exit(0);
    }

    public static void checkUpdate(Activity activity, final boolean silentCheck) {
        UpdateFilesApi.activity = activity;
        UpdateFilesApi.silentCheck = silentCheck;
        downloadFolder = new File(activity.getFilesDir(), DOWNLOAD_FOLDER);

        final ProgressDialog progressDialog = new ProgressDialog(activity);
		
        progressDialog.setMessage("Checking for download...");
        progressDialog.setCancelable(true);           
        if (!isOvpnFilesExist() || !silentCheck) progressDialog.show();           

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, api, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    handleApiResponse(response);              
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }

                    if (!silentCheck) {
                        showInfo(error.getMessage());
                    }                
                }
            });
        Volley.newRequestQueue(activity).add(request);

    }


    private static void updateNow(final int version, final ArrayList<OvpnUpdateModel> updateList) {
        final ProgressDialog progressDialog = new ProgressDialog(activity);
		progressDialog.setIcon(R.drawable.downloading_ic);
		progressDialog.setTitle("Downloading");
        progressDialog.setMessage("Please wait for processing... ");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setCancelable(false);
        progressDialog.setMax(updateList.size());
        progressDialog.setProgress(0);
        progressDialog.show();           

        updatePosition = 0;
        PRDownloader.initialize(activity);

        downloadFile(updateList.get(updatePosition), new OnDownloadListener(){          
                @Override
                public void onDownloadComplete() {
                    if (updatePosition == updateList.size() - 1) {                
                        if (progressDialog.isShowing()) progressDialog.dismiss();
                        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(activity);
                        sp.edit().putInt("version", version).apply();
                        showFilesUpdatedDialog();
                        deleteRestFiles(updateList);

                    } else {
                        updatePosition++;
                        progressDialog.setProgress(updatePosition + 1);
                        downloadFile(updateList.get(updatePosition), this);
                    }
                }       

                @Override
                public void onError(Error error) {
                    progressDialog.dismiss();
                    if (!silentCheck) showInfo("Sorry,try again\n" + error.toString());
                }          
            });
    }

    private static void showFilesUpdatedDialog() {
		
		final Dialog dialog = new Dialog(activity);
		dialog.setContentView(R.layout.success_dialog);
		dialog.setCancelable(false);
		dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
		dialog.getWindow().setBackgroundDrawable(activity.getDrawable(R.drawable.custom_dialog_backgroung));
		dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialog;

		Button done = dialog.findViewById(R.id.no);

		ImageView img = dialog.findViewById(R.id.img);
		Animation slideUp = AnimationUtils.loadAnimation(activity, R.anim.zoom_in);
		img.setAnimation(slideUp);
		
		img.startAnimation(slideUp);

		TextView title1 = dialog.findViewById(R.id.title);
		TextView message1 = dialog.findViewById(R.id.message);

		title1.setText("‌Successful!");
		message1.setText("The download is complete, click DONE");

		done.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v){
					
					triggerRebirth(activity);    

				}

			});



        dialog.show();   
    }
		
		
		
		
       

    private static void deleteRestFiles(final ArrayList<OvpnUpdateModel> updateList) {
        new AsyncTask(){
            @Override
            protected Object doInBackground(Object[] p1) {
                File[] oldFiles = downloadFolder.listFiles();
                if (oldFiles != null) {
                    for (File oldFile : oldFiles) {
                        String oldFileName = oldFile.getName();
                        oldFileName = oldFileName.substring(0, oldFileName.length() - 5);

                        boolean foundRestFile = false;
                        for (OvpnUpdateModel model : updateList) {
                            if (model.name.equals(oldFileName)) {
                                foundRestFile = false;
                                break;
                            } else {
                                foundRestFile = true;
                            }
                        }
                        if (foundRestFile) {
                            oldFile.delete();
                        }
                    }
                }
                return null;
            }          
        }.execute();
    }

    private static void downloadFile(OvpnUpdateModel model, OnDownloadListener listener) {
        PRDownloader.download(model.url, downloadFolder.getPath(), model.name + ".ovpn")
            .build()
            .start(listener);
    }

    private static void showConfirmationDialog(String title, String message, final int version, final ArrayList<OvpnUpdateModel> updateList) {
     
		
		AlertDialog.Builder Builder = new AlertDialog.Builder(activity); 

		final View View = activity.getLayoutInflater().inflate(R.layout.update_dialog, null); 
		Builder.setView(View);
		Builder.setCancelable(false);
		Builder.setNegativeButton(android.R.string.no, null);
		Builder.setPositiveButton("UPDATE", new DialogInterface.OnClickListener(){ 

				@Override public void onClick

				(DialogInterface mDialogInterface, int mInt) { 
					updateNow(version, updateList);
					
				} }); 	
		
		TextView title1 = View.findViewById(R.id.title);
		TextView message1 = View.findViewById(R.id.message);

		title1.setText(title);
		message1.setText(message);	
		
		final AlertDialog dialog2 = Builder.create(); 
		Builder.show();	

    }
		
		


    private static void handleApiResponse(JSONObject response) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(activity);
        try {
            int version = response.getInt("version");
            String title = response.getString("title");
            String message = response.getString("message");

            JSONArray array = response.getJSONArray("files");
            ArrayList<OvpnUpdateModel> updateList = new ArrayList<>();
            for (int i = 0; i < array.length(); i++) {
                JSONObject fileObj = array.getJSONObject(i);
                UpdateFilesApi.OvpnUpdateModel model = new UpdateFilesApi.OvpnUpdateModel(
                    fileObj.getString("name"),
                    fileObj.getString("url")
                );                
                updateList.add(model);
            }

            if (!isOvpnFilesExist() || sp.getInt("version", 0) < version) {
                showConfirmationDialog(title, message, version, updateList);
            } else if (!silentCheck) {
                showInfo("Your config is on latest version");
				
            }         
        } catch (JSONException e) {
            if (!silentCheck) showInfo(e.toString());
        }
    }

    private static void showInfo(String msg) {
		
		
		final Dialog dialog = new Dialog(activity);
		dialog.setContentView(R.layout.success_dialog);
		dialog.setCancelable(false);
		dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
		dialog.getWindow().setBackgroundDrawable(activity.getDrawable(R.drawable.custom_dialog_backgroung));
		dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialog;
		
		Button no = dialog.findViewById(R.id.no);
		ImageView img = dialog.findViewById(R.id.img);
		Animation slideUp = AnimationUtils.loadAnimation(activity, R.anim.zoom_in);
		img.setAnimation(slideUp);

		img.startAnimation(slideUp);
		
		TextView title1 = dialog.findViewById(R.id.title);
		TextView message1 = dialog.findViewById(R.id.message);
		
		title1.setText("Congratulations");
		message1.setText(msg);

		no.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v){
					dialog.dismiss();

				}

			});
		
		
		
        dialog.show();   
    }

    private static boolean isOvpnFilesExist() {
        if (downloadFolder.exists()) {
            File[] files = downloadFolder.listFiles();
            return files != null && files.length > 0;
        } else {
            return false;
        }   
    }
}
