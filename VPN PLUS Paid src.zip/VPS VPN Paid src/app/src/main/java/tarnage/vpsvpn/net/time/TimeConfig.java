package tarnage.vpsvpn.net.time;

public class TimeConfig {
	// Time is calculated in milliseconds
	
	// reward = 2 hours
    public static final long REWARD_TIME = 2 * 60 * 60 * 1000;
	
	// max = 24 hours
    public static final long MAX_REWARD_TIME = 24 * 60 * 60 * 1000;
    
	// bonus = 5 minutes
	public static final long BONUS_TIME = 5 * 60 * 1000;
	
    
}
