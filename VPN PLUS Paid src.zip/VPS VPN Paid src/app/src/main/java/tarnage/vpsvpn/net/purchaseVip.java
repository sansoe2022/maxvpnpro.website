package tarnage.vpsvpn.net;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.Context;
import android.widget.ImageView;
import android.view.View.OnClickListener;
import android.view.View;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.app.Dialog;
import android.view.WindowManager;
import android.widget.Button;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.sdsmdg.tastytoast.TastyToast;
import android.content.Intent;
import android.net.Uri;

public class purchaseVip extends AppCompatActivity {
	
	public void onCreate(Bundle savedInstanceState) {
        if (OpenVPNClientBase.themeSet) {
            setTheme(OpenVPNClientBase.themeResId);
        }

		SharedPreferences sharedPreferences = getSharedPreferences("theme", Context.MODE_PRIVATE);
        setTheme(sharedPreferences.getInt("themeId",OpenVPNClientBase.themeResId));

		super.onCreate(savedInstanceState);
    
		setContentView(R.layout.purchase_vip_layout);
		
		ImageView exit_button = (ImageView) findViewById(R.id.exit_button);
		exit_button.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					finish();
					

				}


			});
			
		final	String msg = "fb-messenger://user/100027250951615";
			
		Button buy_vip = (Button)findViewById(R.id.buy_vip);
		buy_vip.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					
					fb(msg);
				}
			
		});
		
}

// On creat အပြင်




	public void fb(String link){
		ConnectivityManager connectivityManager = (ConnectivityManager)
			getApplicationContext().getSystemService(CONNECTIVITY_SERVICE);

		NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

		if(networkInfo ==null || !networkInfo.isConnected() || !networkInfo.isAvailable()){

			final Dialog dialog = new Dialog(purchaseVip.this);
			dialog.setContentView(R.layout.alert_dialog);
			dialog.setCancelable(false);
			dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
			dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
			dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

			Button add_time = (Button)dialog.findViewById(R.id.add_time);
			add_time.setVisibility(8);

			ImageView bt_tryagain = dialog.findViewById(R.id.bt_tryagain);

			ImageView img = dialog.findViewById(R.id.img);

			Animation slideUp = AnimationUtils.loadAnimation(purchaseVip.this, R.anim.zoom_in);

			img.setAnimation(slideUp);


			img.startAnimation(slideUp);



			bt_tryagain.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v){

						dialog.cancel();


					}
				});
			dialog.show();
			/****Show Toast here*****/		

			TastyToast.makeText(getApplicationContext(), "No internet connection", TastyToast.LENGTH_LONG, TastyToast.ERROR);	
		}else{

			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link)));

		}
	}


	@Override
	public void onBackPressed(){
		super.onBackPressed();
		

	}

	@Override
	protected void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();


	}

}
