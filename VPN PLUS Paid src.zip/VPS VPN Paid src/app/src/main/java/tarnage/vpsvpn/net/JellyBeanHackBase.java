package tarnage.vpsvpn.net;

public class JellyBeanHackBase {
    protected static final boolean ENABLED = true;
}
