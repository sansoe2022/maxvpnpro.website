package tarnage.vpsvpn.net.api;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import tarnage.vpsvpn.net.R;

public class AppUpdater {
	
    private static final String api = new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(new char[]{(char)86,(char)109,(char)48,(char)119,(char)100,(char)50,(char)81,(char)121,(char)86,(char)107,(char)104,(char)86,(char)87,(char)71,(char)104,(char)85,(char)86,(char)48,(char)100,(char)111,(char)99,(char)70,(char)86,(char)116,(char)77,(char)86,(char)78,(char)88,(char)86,(char)108,(char)108,(char)51,(char)87,(char)107,(char)82,(char)83,(char)86,(char)49,(char)90,(char)115,(char)98,(char)68,(char)78,(char)88,(char)97,(char)50,(char)77,(char)49,(char)86,(char)48,(char)90,(char)75,(char)99,(char)50,(char)74,(char)69,(char)84,(char)108,(char)104,(char)104,(char)77,(char)88,(char)66,(char)81,(char)86,(char)109,(char)120,(char)86,(char)101,(char)70,(char)89,(char)121,(char)84,(char)107,(char)108,(char)106,(char)10,(char)82,(char)109,(char)104,(char)111,(char)84,(char)87,(char)115,(char)119,(char)101,(char)70,(char)90,(char)116,(char)99,(char)69,(char)116,(char)84,(char)77,(char)85,(char)53,(char)73,(char)86,(char)109,(char)116,(char)107,(char)87,(char)65,(char)112,(char)105,(char)82,(char)110,(char)66,(char)80,(char)87,(char)87,(char)49,(char)48,(char)83,(char)49,(char)90,(char)87,(char)87,(char)110,(char)82,(char)106,(char)82,(char)88,(char)82,(char)85,(char)84,(char)86,(char)86,(char)115,(char)78,(char)86,(char)90,(char)72,(char)100,(char)72,(char)78,(char)104,(char)85,(char)88,(char)66,(char)84,(char)89,(char)108,(char)90,(char)75,(char)85,(char)70,(char)100,(char)87,(char)90,(char)68,(char)82,(char)90,(char)10,(char)86,(char)49,(char)90,(char)88,(char)86,(char)50,(char)53,(char)83,(char)98,(char)70,(char)73,(char)122,(char)85,(char)108,(char)86,(char)85,(char)86,(char)108,(char)85,(char)120,(char)86,(char)48,(char)90,(char)87,(char)100,(char)69,(char)53,(char)86,(char)79,(char)87,(char)104,(char)82,(char)87,(char)69,(char)74,(char)85,(char)87,(char)87,(char)120,(char)97,(char)83,(char)49,(char)100,(char)87,(char)90,(char)72,(char)78,(char)97,(char)82,(char)70,(char)74,(char)97,(char)67,(char)108,(char)90,(char)115,(char)87,(char)108,(char)104,(char)87,(char)77,(char)106,(char)86,(char)76,(char)86,(char)109,(char)49,(char)70,(char)101,(char)86,(char)86,(char)116,(char)82,(char)108,(char)100,(char)104,(char)10,(char)97,(char)49,(char)112,(char)77,(char)86,(char)84,(char)66,(char)97,(char)89,(char)87,(char)82,(char)70,(char)78,(char)86,(char)90,(char)80,(char)86,(char)50,(char)104,(char)83,(char)86,(char)48,(char)86,(char)75,(char)86,(char)86,(char)100,(char)88,(char)77,(char)84,(char)66,(char)84,(char)77,(char)87,(char)82,(char)88,(char)86,(char)50,(char)53,(char)83,(char)97,(char)108,(char)74,(char)88,(char)85,(char)108,(char)86,(char)68,(char)98,(char)85,(char)112,(char)88,(char)86,(char)50,(char)53,(char)119,(char)87,(char)71,(char)69,(char)120,(char)99,(char)72,(char)74,(char)87,(char)98,(char)84,(char)70,(char)71,(char)90,(char)86,(char)90,(char)87,(char)100,(char)70,(char)74,(char)115,(char)10,(char)90,(char)71,(char)103,(char)75,(char)89,(char)84,(char)70,(char)119,(char)84,(char)86,(char)90,(char)88,(char)99,(char)69,(char)100,(char)86,(char)98,(char)86,(char)90,(char)72,(char)87,(char)107,(char)104,(char)79,(char)89,(char)86,(char)74,(char)116,(char)85,(char)110,(char)74,(char)85,(char)86,(char)69,(char)74,(char)76,(char)90,(char)68,(char)70,(char)97,(char)86,(char)86,(char)70,(char)115,(char)90,(char)70,(char)82,(char)78,(char)98,(char)69,(char)112,(char)54,(char)86,(char)106,(char)74,(char)48,(char)97,(char)49,(char)100,(char)72,(char)83,(char)107,(char)104,(char)86,(char)98,(char)107,(char)112,(char)69,(char)89,(char)88,(char)112,(char)71,(char)86,(char)49,(char)107,(char)119,(char)10,(char)87,(char)109,(char)57,(char)88,(char)82,(char)48,(char)86,(char)52,(char)89,(char)48,(char)104,(char)75,(char)86,(char)50,(char)70,(char)114,(char)99,(char)69,(char)120,(char)87,(char)98,(char)88,(char)104,(char)114,(char)89,(char)122,(char)70,(char)107,(char)99,(char)119,(char)112,(char)87,(char)98,(char)71,(char)78,(char)76,(char)87,(char)87,(char)116,(char)97,(char)100,(char)48,(char)53,(char)115,(char)87,(char)107,(char)104,(char)107,(char)82,(char)48,(char)90,(char)111,(char)84,(char)87,(char)115,(char)49,(char)77,(char)70,(char)86,(char)116,(char)100,(char)71,(char)116,(char)90,(char)86,(char)107,(char)112,(char)122,(char)89,(char)48,(char)100,(char)111,(char)86,(char)86,(char)90,(char)70,(char)10,(char)83,(char)107,(char)120,(char)97,(char)82,(char)69,(char)90,(char)104,(char)90,(char)69,(char)100,(char)87,(char)83,(char)70,(char)74,(char)116,(char)100,(char)69,(char)53,(char)87,(char)98,(char)107,(char)74,(char)90,(char)86,(char)106,(char)74,(char)48,(char)89,(char)87,(char)73,(char)121,(char)83,(char)107,(char)100,(char)84,(char)87,(char)72,(char)66,(char)87,(char)89,(char)109,(char)116,(char)75,(char)82,(char)86,(char)108,(char)89,(char)99,(char)69,(char)100,(char)88,(char)82,(char)108,(char)108,(char)53,(char)67,(char)109,(char)86,(char)72,(char)79,(char)86,(char)104,(char)83,(char)77,(char)70,(char)89,(char)48,(char)87,(char)84,(char)66,(char)111,(char)89,(char)86,(char)100,(char)115,(char)10,(char)87,(char)107,(char)90,(char)88,(char)97,(char)51,(char)82,(char)104,(char)86,(char)106,(char)78,(char)111,(char)87,(char)70,(char)108,(char)54,(char)82,(char)109,(char)116,(char)106,(char)100,(char)51,(char)66,(char)88,(char)89,(char)107,(char)100,(char)79,(char)84,(char)70,(char)90,(char)71,(char)85,(char)107,(char)116,(char)105,(char)77,(char)86,(char)74,(char)88,(char)86,(char)50,(char)120,(char)87,(char)85,(char)109,(char)74,(char)86,(char)87,(char)109,(char)70,(char)87,(char)98,(char)84,(char)70,(char)84,(char)85,(char)106,(char)70,(char)83,(char)99,(char)49,(char)100,(char)116,(char)100,(char)70,(char)112,(char)87,(char)97,(char)51,(char)65,(char)119,(char)87,(char)86,(char)86,(char)97,(char)10,(char)84,(char)49,(char)89,(char)119,(char)77,(char)85,(char)99,(char)75,(char)86,(char)50,(char)116,(char)52,(char)89,(char)86,(char)74,(char)70,(char)87,(char)109,(char)104,(char)97,(char)82,(char)87,(char)82,(char)80,(char)85,(char)109,(char)115,(char)53,(char)87,(char)71,(char)74,(char)70,(char)78,(char)87,(char)108,(char)83,(char)86,(char)109,(char)116,(char)51,(char)86,(char)109,(char)112,(char)75,(char)77,(char)70,(char)108,(char)88,(char)83,(char)88,(char)108,(char)83,(char)87,(char)71,(char)104,(char)85,(char)89,(char)109,(char)120,(char)75,(char)86,(char)49,(char)108,(char)116,(char)100,(char)72,(char)100,(char)83,(char)86,(char)109,(char)120,(char)90,(char)89,(char)48,(char)86,(char)107,(char)10,(char)98,(char)71,(char)74,(char)71,(char)98,(char)68,(char)86,(char)68,(char)97,(char)122,(char)86,(char)90,(char)87,(char)107,(char)90,(char)111,(char)85,(char)48,(char)49,(char)71,(char)87,(char)84,(char)66,(char)88,(char)86,(char)69,(char)74,(char)118,(char)87,(char)86,(char)90,(char)90,(char)101,(char)65,(char)112,(char)84,(char)87,(char)72,(char)66,(char)111,(char)85,(char)108,(char)104,(char)111,(char)86,(char)49,(char)108,(char)115,(char)97,(char)71,(char)57,(char)106,(char)98,(char)71,(char)119,(char)50,(char)85,(char)109,(char)53,(char)107,(char)85,(char)50,(char)81,(char)122,(char)81,(char)110,(char)70,(char)86,(char)97,(char)107,(char)111,(char)119,(char)86,(char)69,(char)90,(char)97,(char)10,(char)87,(char)69,(char)49,(char)69,(char)82,(char)108,(char)74,(char)78,(char)86,(char)107,(char)112,(char)89,(char)86,(char)106,(char)73,(char)49,(char)82,(char)49,(char)86,(char)116,(char)83,(char)108,(char)90,(char)88,(char)98,(char)107,(char)90,(char)86,(char)86,(char)109,(char)120,(char)119,(char)77,(char)49,(char)89,(char)119,(char)87,(char)109,(char)70,(char)88,(char)82,(char)84,(char)86,(char)88,(char)87,(char)107,(char)90,(char)107,(char)86,(char)48,(char)49,(char)73,(char)81,(char)107,(char)108,(char)88,(char)86,(char)69,(char)74,(char)104,(char)67,(char)108,(char)81,(char)120,(char)87,(char)88,(char)100,(char)78,(char)86,(char)87,(char)78,(char)76,(char)86,(char)106,(char)74,(char)48,(char)10,(char)78,(char)70,(char)89,(char)119,(char)77,(char)88,(char)86,(char)104,(char)82,(char)50,(char)104,(char)88,(char)84,(char)85,(char)90,(char)87,(char)78,(char)70,(char)90,(char)115,(char)87,(char)107,(char)100,(char)107,(char)82,(char)49,(char)74,(char)71,(char)84,(char)108,(char)90,(char)107,(char)97,(char)69,(char)49,(char)88,(char)100,(char)68,(char)78,(char)87,(char)98,(char)84,(char)70,(char)51,(char)85,(char)122,(char)65,(char)120,(char)83,(char)70,(char)74,(char)89,(char)97,(char)70,(char)104,(char)105,(char)98,(char)69,(char)112,(char)85,(char)86,(char)106,(char)66,(char)107,(char)85,(char)50,(char)78,(char)87,(char)86,(char)110,(char)78,(char)86,(char)98,(char)107,(char)53,(char)84,(char)10,(char)86,(char)109,(char)49,(char)52,(char)101,(char)86,(char)89,(char)121,(char)78,(char)85,(char)56,(char)75,(char)86,(char)71,(char)115,(char)120,(char)87,(char)71,(char)86,(char)73,(char)98,(char)69,(char)82,(char)105,(char)82,(char)108,(char)112,(char)54,(char)86,(char)107,(char)100,(char)52,(char)98,(char)50,(char)70,(char)87,(char)87,(char)108,(char)100,(char)88,(char)86,(char)69,(char)90,(char)89,(char)86,(char)109,(char)120,(char)97,(char)97,(char)70,(char)90,(char)85,(char)82,(char)108,(char)112,(char)108,(char)81,(char)88,(char)66,(char)85,(char)89,(char)84,(char)70,(char)119,(char)87,(char)86,(char)108,(char)115,(char)90,(char)71,(char)57,(char)88,(char)82,(char)109,(char)120,(char)121,(char)10,(char)87,(char)107,(char)90,(char)79,(char)86,(char)86,(char)74,(char)115,(char)86,(char)106,(char)82,(char)87,(char)77,(char)110,(char)77,(char)49,(char)89,(char)87,(char)49,(char)82,(char)101,(char)108,(char)70,(char)117,(char)82,(char)108,(char)90,(char)104,(char)97,(char)51,(char)66,(char)121,(char)86,(char)107,(char)86,(char)97,(char)89,(char)81,(char)112,(char)83,(char)77,(char)87,(char)116,(char)54,(char)89,(char)85,(char)100,(char)115,(char)84,(char)108,(char)90,(char)89,(char)81,(char)108,(char)108,(char)87,(char)97,(char)107,(char)107,(char)120,(char)86,(char)84,(char)70,(char)83,(char)99,(char)49,(char)100,(char)114,(char)90,(char)70,(char)82,(char)105,(char)82,(char)50,(char)104,(char)104,(char)10,(char)87,(char)87,(char)116,(char)97,(char)100,(char)50,(char)70,(char)71,(char)86,(char)88,(char)104,(char)88,(char)98,(char)71,(char)82,(char)114,(char)85,(char)106,(char)70,(char)75,(char)83,(char)86,(char)81,(char)120,(char)90,(char)71,(char)57,(char)85,(char)98,(char)70,(char)112,(char)90,(char)85,(char)87,(char)112,(char)97,(char)86,(char)50,(char)70,(char)114,(char)98,(char)68,(char)82,(char)68,(char)98,(char)85,(char)108,(char)52,(char)86,(char)50,(char)120,(char)107,(char)87,(char)71,(char)69,(char)120,(char)98,(char)69,(char)120,(char)87,(char)86,(char)69,(char)111,(char)119,(char)67,(char)107,(char)53,(char)71,(char)98,(char)70,(char)100,(char)84,(char)87,(char)72,(char)66,(char)111,(char)10,(char)85,(char)48,(char)86,(char)119,(char)87,(char)70,(char)108,(char)88,(char)100,(char)71,(char)70,(char)88,(char)82,(char)109,(char)116,(char)53,(char)84,(char)86,(char)90,(char)79,(char)85,(char)50,(char)70,(char)54,(char)86,(char)108,(char)100,(char)85,(char)98,(char)71,(char)82,(char)122,(char)86,(char)84,(char)74,(char)75,(char)99,(char)108,(char)78,(char)116,(char)82,(char)108,(char)100,(char)105,(char)87,(char)69,(char)74,(char)77,(char)86,(char)70,(char)86,(char)97,(char)99,(char)49,(char)100,(char)71,(char)84,(char)108,(char)108,(char)105,(char)82,(char)107,(char)53,(char)112,(char)89,(char)88,(char)112,(char)87,(char)86,(char)108,(char)100,(char)88,(char)100,(char)71,(char)70,(char)90,(char)10,(char)86,(char)48,(char)53,(char)72,(char)86,(char)109,(char)53,(char)71,(char)85,(char)109,(char)74,(char)86,(char)87,(char)108,(char)81,(char)75,(char)86,(char)109,(char)48,(char)120,(char)78,(char)71,(char)86,(char)87,(char)87,(char)88,(char)108,(char)79,(char)86,(char)84,(char)104,(char)76,(char)86,(char)107,(char)82,(char)71,(char)83,(char)50,(char)77,(char)120,(char)90,(char)72,(char)70,(char)82,(char)97,(char)49,(char)74,(char)112,(char)86,(char)108,(char)82,(char)87,(char)83,(char)86,(char)89,(char)121,(char)100,(char)71,(char)70,(char)104,(char)77,(char)107,(char)90,(char)73,(char)86,(char)109,(char)53,(char)75,(char)87,(char)71,(char)70,(char)115,(char)83,(char)108,(char)104,(char)90,(char)10,(char)98,(char)70,(char)74,(char)71,(char)90,(char)68,(char)70,(char)97,(char)86,(char)86,(char)74,(char)115,(char)99,(char)71,(char)120,(char)82,(char)87,(char)69,(char)74,(char)86,(char)86,(char)106,(char)66,(char)111,(char)81,(char)50,(char)73,(char)120,(char)86,(char)110,(char)70,(char)84,(char)98,(char)84,(char)108,(char)88,(char)89,(char)107,(char)100,(char)52,(char)101,(char)103,(char)112,(char)90,(char)86,(char)87,(char)77,(char)49,(char)86,(char)108,(char)90,(char)75,(char)100,(char)86,(char)70,(char)114,(char)90,(char)70,(char)100,(char)105,(char)82,(char)107,(char)112,(char)89,(char)86,(char)109,(char)112,(char)75,(char)85,(char)109,(char)86,(char)115,(char)82,(char)110,(char)82,(char)104,(char)10,(char)82,(char)108,(char)112,(char)111,(char)89,(char)84,(char)78,(char)67,(char)101,(char)86,(char)90,(char)114,(char)86,(char)109,(char)70,(char)104,(char)100,(char)51,(char)66,(char)88,(char)84,(char)87,(char)116,(char)97,(char)83,(char)108,(char)100,(char)114,(char)87,(char)109,(char)116,(char)85,(char)98,(char)69,(char)112,(char)71,(char)86,(char)50,(char)112,(char)97,(char)86,(char)48,(char)49,(char)117,(char)85,(char)109,(char)104,(char)90,(char)101,(char)107,(char)112,(char)72,(char)89,(char)122,(char)70,(char)79,(char)99,(char)50,(char)70,(char)71,(char)87,(char)109,(char)108,(char)83,(char)77,(char)85,(char)112,(char)88,(char)67,(char)108,(char)90,(char)116,(char)77,(char)84,(char)82,(char)90,(char)10,(char)86,(char)84,(char)66,(char)52,(char)86,(char)49,(char)104,(char)107,(char)87,(char)71,(char)74,(char)86,(char)87,(char)108,(char)86,(char)86,(char)97,(char)107,(char)90,(char)104,(char)85,(char)50,(char)120,(char)97,(char)83,(char)69,(char)49,(char)88,(char)79,(char)86,(char)90,(char)78,(char)97,(char)49,(char)89,(char)49,(char)87,(char)107,(char)104,(char)119,(char)82,(char)49,(char)100,(char)71,(char)87,(char)110,(char)78,(char)88,(char)98,(char)87,(char)104,(char)69,(char)89,(char)107,(char)90,(char)71,(char)78,(char)70,(char)89,(char)120,(char)97,(char)71,(char)116,(char)85,(char)98,(char)70,(char)112,(char)89,(char)86,(char)71,(char)116,(char)52,(char)86,(char)50,(char)70,(char)114,(char)10,(char)98,(char)51,(char)100,(char)68,(char)97,(char)122,(char)86,(char)72,(char)89,(char)107,(char)90,(char)107,(char)86,(char)70,(char)100,(char)73,(char)81,(char)109,(char)56,(char)75,(char)86,(char)87,(char)112,(char)75,(char)98,(char)50,(char)70,(char)71,(char)86,(char)110,(char)78,(char)88,(char)98,(char)70,(char)112,(char)115,(char)85,(char)109,(char)120,(char)115,(char)78,(char)70,(char)89,(char)121,(char)78,(char)87,(char)116,(char)86,(char)77,(char)68,(char)70,(char)89,(char)86,(char)87,(char)53,(char)115,(char)86,(char)87,(char)74,(char)71,(char)99,(char)70,(char)66,(char)87,(char)86,(char)69,(char)90,(char)104,(char)90,(char)69,(char)85,(char)53,(char)83,(char)87,(char)74,(char)71,(char)10,(char)90,(char)71,(char)108,(char)87,(char)82,(char)85,(char)108,(char)54,(char)86,(char)50,(char)120,(char)87,(char)86,(char)107,(char)49,(char)87,(char)84,(char)107,(char)100,(char)84,(char)98,(char)71,(char)120,(char)112,(char)85,(char)109,(char)115,(char)49,(char)98,(char)49,(char)82,(char)88,(char)101,(char)69,(char)116,(char)87,(char)98,(char)71,(char)82,(char)89,(char)90,(char)69,(char)100,(char)71,(char)97,(char)119,(char)112,(char)78,(char)86,(char)108,(char)112,(char)73,(char)86,(char)106,(char)70,(char)111,(char)97,(char)49,(char)89,(char)121,(char)83,(char)110,(char)82,(char)86,(char)98,(char)70,(char)70,(char)76,(char)86,(char)109,(char)48,(char)119,(char)101,(char)69,(char)53,(char)71,(char)10,(char)90,(char)72,(char)78,(char)104,(char)77,(char)50,(char)82,(char)88,(char)89,(char)108,(char)104,(char)79,(char)84,(char)70,(char)90,(char)113,(char)81,(char)109,(char)70,(char)84,(char)77,(char)108,(char)74,(char)73,(char)86,(char)87,(char)116,(char)87,(char)86,(char)87,(char)69,(char)120,(char)83,(char)110,(char)66,(char)86,(char)97,(char)107,(char)90,(char)75,(char)90,(char)85,(char)90,(char)90,(char)101,(char)87,(char)82,(char)72,(char)82,(char)109,(char)104,(char)78,(char)97,(char)49,(char)112,(char)89,(char)86,(char)84,(char)73,(char)49,(char)85,(char)49,(char)86,(char)71,(char)84,(char)107,(char)104,(char)108,(char)82,(char)109,(char)104,(char)88,(char)67,(char)109,(char)70,(char)114,(char)10,(char)78,(char)88,(char)90,(char)97,(char)82,(char)51,(char)104,(char)122,(char)86,(char)108,(char)90,(char)75,(char)99,(char)50,(char)78,(char)72,(char)100,(char)71,(char)116,(char)78,(char)77,(char)69,(char)112,(char)81,(char)86,(char)109,(char)112,(char)67,(char)89,(char)86,(char)108,(char)88,(char)83,(char)88,(char)104,(char)87,(char)87,(char)71,(char)82,(char)88,(char)89,(char)109,(char)49,(char)83,(char)87,(char)70,(char)82,(char)87,(char)90,(char)68,(char)82,(char)88,(char)85,(char)88,(char)66,(char)104,(char)85,(char)108,(char)100,(char)83,(char)83,(char)70,(char)90,(char)116,(char)101,(char)69,(char)116,(char)107,(char)86,(char)107,(char)90,(char)121,(char)89,(char)85,(char)90,(char)107,(char)10,(char)84,(char)109,(char)74,(char)116,(char)97,(char)70,(char)70,(char)88,(char)86,(char)109,(char)78,(char)52,(char)86,(char)87,(char)49,(char)87,(char)99,(char)49,(char)74,(char)117,(char)84,(char)109,(char)103,(char)75,(char)85,(char)109,(char)53,(char)67,(char)98,(char)49,(char)82,(char)87,(char)87,(char)108,(char)112,(char)78,(char)82,(char)108,(char)112,(char)121,(char)86,(char)109,(char)49,(char)71,(char)97,(char)71,(char)81,(char)122,(char)81,(char)110,(char)70,(char)85,(char)86,(char)109,(char)104,(char)68,(char)85,(char)109,(char)120,(char)87,(char)87,(char)71,(char)86,(char)72,(char)79,(char)87,(char)104,(char)87,(char)98,(char)72,(char)66,(char)54,(char)87,(char)84,(char)66,(char)83,(char)10,(char)89,(char)86,(char)89,(char)119,(char)77,(char)88,(char)86,(char)86,(char)98,(char)108,(char)112,(char)88,(char)85,(char)107,(char)86,(char)97,(char)99,(char)108,(char)107,(char)121,(char)99,(char)51,(char)104,(char)84,(char)86,(char)48,(char)112,(char)73,(char)89,(char)85,(char)90,(char)79,(char)97,(char)86,(char)74,(char)117,(char)81,(char)109,(char)57,(char)68,(char)98,(char)71,(char)82,(char)89,(char)90,(char)69,(char)100,(char)71,(char)97,(char)119,(char)112,(char)78,(char)97,(char)49,(char)112,(char)73,(char)86,(char)106,(char)73,(char)49,(char)82,(char)49,(char)85,(char)121,(char)83,(char)107,(char)90,(char)79,(char)87,(char)69,(char)90,(char)86,(char)86,(char)109,(char)120,(char)119,(char)10,(char)77,(char)49,(char)112,(char)88,(char)101,(char)71,(char)116,(char)106,(char)98,(char)71,(char)82,(char)122,(char)87,(char)107,(char)100,(char)111,(char)86,(char)50,(char)69,(char)122,(char)81,(char)109,(char)70,(char)87,(char)86,(char)109,(char)81,(char)119,(char)89,(char)84,(char)70,(char)90,(char)101,(char)70,(char)100,(char)117,(char)84,(char)109,(char)112,(char)83,(char)98,(char)69,(char)112,(char)70,(char)87,(char)87,(char)120,(char)86,(char)77,(char)87,(char)86,(char)115,(char)86,(char)108,(char)104,(char)108,(char)82,(char)88,(char)82,(char)87,(char)86,(char)109,(char)120,(char)119,(char)82,(char)108,(char)86,(char)87,(char)85,(char)110,(char)74,(char)81,(char)85,(char)84,(char)48,(char)57}).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT));
    private static Activity activity;
    private static boolean silentCheck;
	
	
	
	
	
	public static void checkAppUpdate(Activity activity, final boolean silentCheck) {
        AppUpdater.activity = activity;
        AppUpdater.silentCheck = silentCheck;
        
        final ProgressDialog progressDialog = new ProgressDialog(activity);
		
        progressDialog.setMessage("Checking update...");
        progressDialog.setCancelable(true);     
		if (!silentCheck) progressDialog.show(); 
		JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, api, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    handleApiResponse(response);              
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }

                    if (!silentCheck) {
                        showInfo(error.getMessage());
                    }                
                }
            });
        Volley.newRequestQueue(activity).add(request);

    }

	
	
	private static void showConfirmationDialog(final String link, String title, String message, final int version) {
		
		AlertDialog.Builder Builder = new AlertDialog.Builder(activity); 

		final View View = activity.getLayoutInflater().inflate(R.layout.update_dialog, null); 
		Builder.setView(View);

		Builder.setCancelable(false);
		Builder.setPositiveButton("UPDATE", new DialogInterface.OnClickListener(){ 

				@Override public void onClick

				(DialogInterface mDialogInterface, int mInt) { 
					activity.startActivityForResult(new Intent(Intent.ACTION_VIEW, Uri.parse("https://"+link)), 0);

				} });
		
		TextView title1 = View.findViewById(R.id.title);
		TextView message1 = View.findViewById(R.id.message);

		title1.setText(title);
		message1.setText(message);	

		final AlertDialog dialog2 = Builder.create(); 
		if (dialog2.getWindow() != null)
			dialog2.getWindow().getAttributes().windowAnimations = R.style.PauseDialog;

		dialog2.show();
		
		
					
    }
		
			
	
	private static void handleApiResponse(JSONObject response) {
        
		try {
			PackageInfo pInfo = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
			int appVersionCode = pInfo.versionCode;
			try {
				int version = response.getInt("version");
				String title = response.getString("title");
				String message = response.getString("message");
				String link = response.getString("link");

				if (version > appVersionCode) {
					showConfirmationDialog(link, title, message, version);
				} else if (!silentCheck) {
					showInfo("Your app is up to date");
				}         
			} catch (JSONException e) {
				if (!silentCheck) showInfo(e.toString());
			}
		
		
			
			
			
			} catch (PackageManager.NameNotFoundException e) {}
		
		}
        
	private static void showInfo(String msg) {
		final Dialog dialog = new Dialog(activity);
		dialog.setContentView(R.layout.success_dialog);
		dialog.setCancelable(false);
		dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
		dialog.getWindow().setBackgroundDrawable(activity.getDrawable(R.drawable.custom_dialog_backgroung));
		dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialog;

		Button no = dialog.findViewById(R.id.no);

		TextView title1 = dialog.findViewById(R.id.title);
		TextView message1 = dialog.findViewById(R.id.message);
		ImageView img = dialog.findViewById(R.id.img);
		Animation slideUp = AnimationUtils.loadAnimation(activity, R.anim.zoom_in);
		img.setAnimation(slideUp);

		img.startAnimation(slideUp);
		
		title1.setText("Congratulations!");
		message1.setText(msg);

		no.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v){
					dialog.dismiss();

				}

			});



        dialog.show();   
    }
	
	
    
}
