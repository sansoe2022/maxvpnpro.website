package tarnage.vpsvpn.net.ads;

public class AdConfig {

    public static final String REWARD_UNIT = "ca-app-pub-3940256099942544/5224354917";


}

